#include "./adjacentmatrix.h"

int main()
{
	Graphmatrix<int,int> myGra;
	cin>>myGra;
	cout<<myGra<<endl;
	return 0;
}
